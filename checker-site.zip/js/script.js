let db;

function abrirDB() {
  return new Promise((resolve) => {
    const req = indexedDB.open("BancoChassi", 1);

    req.onupgradeneeded = e => {
      db = e.target.result;
      db.createObjectStore("chassis", { keyPath: "chassi" });
    };

    req.onsuccess = e => {
      db = e.target.result;
      resolve();
    };
  });
}

async function importarBanco() {
  await abrirDB();

  const file = document.getElementById("bancoFile").files[0];
  if (!file) return alert("Selecione o arquivo");

  const status = document.getElementById("status");
  status.textContent = "Importando banco...";

  const reader = file.stream().getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const linhas = buffer.split("\n");
    buffer = linhas.pop();

    const tx = db.transaction("chassis", "readwrite");
    const store = tx.objectStore("chassis");

    for (const linha of linhas) {
      const [chassi, placa] = linha.trim().split(";");
      if (chassi) {
        store.put({ chassi, placa: placa || "" });
        total++;
      }
    }

    status.textContent = `Importados: ${total.toLocaleString()}`;
  }

  status.textContent = `Banco pronto: ${total.toLocaleString()} registros`;
}

async function verificar() {
  await abrirDB();

  const input = document.getElementById("lista").value;
  const chassis = input.split("\n").map(c => c.trim()).filter(Boolean);

  const com = [];
  const sem = [];

  const tx = db.transaction("chassis", "readonly");
  const store = tx.objectStore("chassis");

  for (const chassi of chassis) {
    const req = store.get(chassi);
    await new Promise(r => {
      req.onsuccess = () => {
        if (req.result && req.result.placa) {
          com.push(`${chassi} → ${req.result.placa}`);
        } else {
          sem.push(chassi);
        }
        r();
      };
    });
  }

  document.getElementById("comPlaca").textContent = com.join("\n");
  document.getElementById("semPlaca").textContent = sem.join("\n");
}